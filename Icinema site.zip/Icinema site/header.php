<html>

<!DOCTYPE html>
<html lang="en">
<head><link href='custom.css' rel='stylesheet' type='text/css'>
  <title>Icinema</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
  
 
<!-- TITLE FONT -->
<link href='http://fonts.googleapis.com/css?family=Ubuntu:400,700' rel='stylesheet' type='text/css'>


<!-- script-->
<script src="scripts/font.js"></script>
<!-->


 <!-- font style -->
  <link href='http://fonts.googleapis.com/css?family=Cabin' rel='stylesheet' type='text/css'>
<!--close-->
  <!--custom stylesheet-->
  <link href='css/custom.css' rel='stylesheet' type='text/css'>
  <!--close-->
  <script type="text/javascript">
  WebFontConfig = {
    google: { families: [ 'Cabin::latin' ] }
  };
  (function() {
    var wf = document.createElement('script');
    wf.src = ('https:' == document.location.protocol ? 'https' : 'http') +
      '://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';
    wf.type = 'text/javascript';
    wf.async = 'true';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(wf, s);
  })(); </script>
</head>
<body style=" background: url('background.png'); 
    background-position:center center;
    background-repeat:no-repeat;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;background-attachment: fixed;">


<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="index.html">Icinema</a>
    </div>
    <div>
      <ul class="nav navbar-nav">
        <li class="active"><a href="index.html">Home</a></li>
        <li><a href="bookingtest2.php">book tickets</a></li>
        <li><a href="games.html">games</a></li>
        <li><a href="#"></a></li>
      </ul>
    </div>
  </div>
</nav>
  

<div class="container">
  <div style="border-radius:4px;
     background-image:
    radial-gradient(
          #ccc,
      #505050 50%
    );" class="jumbotron">
  
<h1 style="color:#ff8040"> Register </h1>
  
    
    <p>
	
	<!--twitter follow button-->
	
	<a href="https://twitter.com/intent/tweet?screen_name=Icinema" class="twitter-mention-button" data-size="large">Tweet to @Icinema</a>
  <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');
  </script>
  
  <!--close-->
  
  
  
 

   <!-- -->
   <a class="btn btn-warning pull-right" href="login.html">Login</a><a href="register.html" class="btn btn-warning pull-right">register</a>
  
  </p>
  
  
  </div>