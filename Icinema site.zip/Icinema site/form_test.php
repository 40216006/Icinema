<form action="bookingscript2.php" method="POST">

<input name="bookdate" type="date">

<input name="Event_title" type="text">

<input name="booktickets" type="text">

<input name="submit" type="submit">

</form>  