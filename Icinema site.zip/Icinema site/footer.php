<footer class="site-footer no-margin">
<p class="text-center">  <ul><li><a  href="adminlogin.html">Admin login</a></li><li><a href="controlpanel.php">Admin control panel</a> </li></ul>         </p>

 </footer>